package signInfunc;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegisterRepo;
import repository.SignInRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;

import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class SignInTest {
	WebDriver driver;
	  @BeforeTest
	  public void beforeTest() throws InterruptedException 
	  {
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  Thread.sleep(2000);
	  }
	  

  @Test
  public void signIn() throws IOException, InterruptedException
  {
	  FileInputStream file=new FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
	  XSSFWorkbook w=new XSSFWorkbook(file); 
	  XSSFSheet s=w.getSheet("demo_test");
	  
	  int rowsize=s.getLastRowNum();
	  System.out.println("No of data: "+ rowsize);
	  
	  SignInRepo.url(driver);
	  
	  for(int i=1; i<=rowsize; i++)
	  {
		  String  Mobile_No=s.getRow(i).getCell(0).getStringCellValue();
		  
		  try 
		  {
		  SignInRepo.login(driver).sendKeys(Mobile_No);
		  Thread.sleep(2000);
		  SignInRepo.Continue(driver).click();
		  Thread.sleep(15000);
		  SignInRepo.startshopping (driver).click();
		  Thread.sleep(2000);
		  SignInRepo.sign_out(driver).click();
		  Thread.sleep(3000);
		  SignInRepo.sign_in(driver).click();
		  Thread.sleep(2000);
		  System.out.println("valid data");
	      System.out.println("");
	    	 
	    	 
	      }
	      
	  
	      catch(Exception e)
	      {
	    	 SignInRepo.login(driver).clear();
	    	 System.out.println("invalid data");
	    	 System.out.println("");
	      }
	    	  
	  }
  }
	  @AfterTest
		public void afterTest() 
		{
			driver.close();
		}
	  
  }

		  
			
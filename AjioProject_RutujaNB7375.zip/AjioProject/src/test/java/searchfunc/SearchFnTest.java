package searchfunc;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.SearchFnRepo;
import repository.SignInRepo;

public class SearchFnTest 
{
	

	WebDriver driver;
	  @BeforeTest
	  public void beforeTest() throws InterruptedException 
	  {
		  WebDriverManager.chromedriver().setup();
		  driver = new ChromeDriver();
		  driver.manage().window().maximize();
		  Thread.sleep(2000);
	  }

@Test
public void searching() throws IOException, InterruptedException
{
	 FileInputStream file=new FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
	  XSSFWorkbook w=new XSSFWorkbook(file); 
  XSSFSheet s=w.getSheet("Search_Product");
	  
	  int rowsize=s.getLastRowNum();
	  System.out.println("No of products "+ rowsize);
	  
	  
	  	
	  for(int i=1; i<=rowsize; i++)
	  {
		  String Products=s.getRow(i).getCell(0).getStringCellValue();
		  
		  System.out.println("Products:" +Products );
		  
		  try
		  {
		  SearchFnRepo.url(driver);
		  Thread.sleep(2000);
		  
		  SearchFnRepo.Search_Bar(driver).sendKeys(Products);
		  Thread.sleep(2000);
		  
		  SearchFnRepo.Searchbtn(driver).sendKeys(Products);
		  Thread.sleep(2000);
		  
		  System.out.println("valid data");
	      System.out.println("");
			 
	      }
	      
	  
	      catch(Exception e)
	      {
	    	
	    	 System.out.println("invalid data");
	    	 System.out.println("");
	      }
		  SearchFnRepo.Search_Bar(driver).clear();  
	  }
  }
	  @AfterTest
		public void afterTest() 
		{
			driver.close();
		}
	  
  }


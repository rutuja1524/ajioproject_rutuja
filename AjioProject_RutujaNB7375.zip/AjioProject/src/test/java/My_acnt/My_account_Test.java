package My_acnt;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.My_acnt_Repo;
import repository.SignInRepo;

public class My_account_Test 
{
	
		WebDriver driver;
		  @BeforeTest
		  
		  public void beforeTest() throws InterruptedException 
		  {
			  WebDriverManager.chromedriver().setup();
			  driver = new ChromeDriver();
			  driver.manage().window().maximize();
			  Thread.sleep(2000);
		  }
		  

	  @Test
	  public void my_acnt_test() throws IOException, InterruptedException
	  {
		  FileInputStream file=new FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
		  XSSFWorkbook w=new XSSFWorkbook(file); 
		  XSSFSheet s=w.getSheet("My_acnt");
		  
		  int rowsize=s.getLastRowNum();
		  System.out.println("No of data: "+ rowsize);
		  
		  My_acnt_Repo.url(driver);
		  
		  for(int i=1; i<=rowsize; i++)
		  {
			  String  Mobile_No=s.getRow(i).getCell(0).getStringCellValue();
			  String New_Pwd=s.getRow(i).getCell(1).getStringCellValue();
			 
			  My_acnt_Repo.login(driver).sendKeys(Mobile_No);
			  Thread.sleep(2000);
			  My_acnt_Repo.Continue(driver).click();
			  Thread.sleep(15000);
			  My_acnt_Repo.startshopping (driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.my_acnt(driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.updt_personal_info(driver).click();
			  Thread.sleep(15000);
			  My_acnt_Repo.confirm_otp_for_updtn(driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.change_btn_pwd(driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.pwd_field(driver).sendKeys(New_Pwd);
			  Thread.sleep(2000);
			  My_acnt_Repo.save_new_pwd_btn(driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.login(driver).sendKeys(Mobile_No);
			  Thread.sleep(2000);
			  My_acnt_Repo.Continue(driver).click();
			  Thread.sleep(15000);
			  My_acnt_Repo.startshopping (driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.sign_out(driver).click();
			  Thread.sleep(2000);
			  My_acnt_Repo.sign_in(driver).click();
			  Thread.sleep(2000);
			  System.out.println("Password has been changed");
		      System.out.println("");
		    	 
		    	 
		      }
		  }
	  
		  @AfterTest
			public void afterTest() 
			{
				driver.close();
			}
		  
	  }

			  

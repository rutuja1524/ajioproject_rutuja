package registration;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegisterRepo;
import repository.SignInRepo;

public class Registration_agio_test 
{
	WebDriver driver;
	@BeforeTest
	 public void beforeTest() throws InterruptedException
	 {
		
		 WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
		 
		
	 }
	  @Test
	  public void registration() throws InterruptedException, IOException
	  {
		  
		  FileInputStream file=new   FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
		  XSSFWorkbook w=new  XSSFWorkbook(file);
		  XSSFSheet s=w.getSheet("testing_reg");
		  int rowsize=s.getLastRowNum();
		  
		  System.out.println("No of data:" + rowsize);
		  
		  for(int i=1; i<=rowsize; i++)
		  {
			  
			  RegisterRepo.url(driver);
				Thread.sleep(2000);
				System.out.println(driver.getTitle());
			  
				RegisterRepo.sign_in(driver).click();
				Thread.sleep(2000);
			  
			    String  Mobile_No=s.getRow(i).getCell(0).getStringCellValue();
				String Name=s.getRow(i).getCell(1).getStringCellValue();
				String Email=s.getRow(i).getCell(2).getStringCellValue();
				String Passwords=s.getRow(i).getCell(3).getStringCellValue();
				
				
				RegisterRepo.login(driver).sendKeys(Mobile_No);
				  Thread.sleep(2000);
				
				RegisterRepo.Continue(driver).click();
				Thread.sleep(2000);
				
				
				
				/*RegisterRepo.sign_out(driver).click();
				Thread.sleep(2000);
			    RegisterRepo.sign_in(driver).click();*/
				
				driver.navigate().back();
				 try 
				  {
					 
					 RegisterRepo.fGender(driver).click();
						Thread.sleep(2000);
						
						RegisterRepo.username(driver).sendKeys(Name);
						Thread.sleep(2000);
						
						RegisterRepo.useremail(driver).sendKeys(Email);
						Thread.sleep(2000);
						
						RegisterRepo.password(driver).sendKeys(Passwords);
						Thread.sleep(2000);
						
						RegisterRepo.tickButton(driver).click();
						Thread.sleep(2000);
						
						RegisterRepo.sendOTP(driver).click();
						Thread.sleep(30000);
						
						RegisterRepo.startshopping(driver).click();
						Thread.sleep(3000);
						
				
				System.out.println("valid data");
			    System.out.println("");
			    	 
			    	 
			      }
		 
		  catch(Exception e)
			      {
			    	 
			    	 System.out.println("invalid data");
			    	 System.out.println("");
			    	 
			      }
				  
			  }
		  }
						
					
					
			  @AfterTest
				public void afterTest() 
				{
					driver.close();
				}
			  
		  }
		 
		  
package registration;

import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.RegisterRepo;
import repository.SignInRepo;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class Register 
{
	WebDriver driver;


	@BeforeTest
	public void beforeTest() throws InterruptedException 
	{
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		Thread.sleep(2000);
	}

	@Test
	public void Register() throws IOException, InterruptedException 
	{
		FileInputStream file=new FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
		XSSFWorkbook w=new XSSFWorkbook(file); 
		XSSFSheet s=w.getSheet("testing_reg");

		int rowsize=s.getLastRowNum();
		System.out.println("No of data: "+ rowsize);

		RegisterRepo.url(driver);

		for(int i=1; i<=rowsize; i++)
		{
			String  Mobile_No=s.getRow(i).getCell(0).getStringCellValue();
			String Name=s.getRow(i).getCell(1).getStringCellValue();
			String Email=s.getRow(i).getCell(2).getStringCellValue();
			String Passwords=s.getRow(i).getCell(3).getStringCellValue();
			
			RegisterRepo.login(driver).sendKeys(Mobile_No);
			Thread.sleep(3000);
			RegisterRepo.Continue(driver).click();
			Thread.sleep(3000);


				if(driver.getCurrentUrl().contains("register")) 
				{
					
					System.out.println("Not a registered user");
					RegisterRepo.fGender(driver).click();
					RegisterRepo.username(driver).sendKeys(Name);
					RegisterRepo.useremail(driver).sendKeys(Email);
					RegisterRepo.password(driver).sendKeys(Passwords);
					RegisterRepo.tickButton(driver).click();
					RegisterRepo.sendOTP(driver).click();
					Thread.sleep(15000);
					RegisterRepo.startshopping(driver).click();
					Thread.sleep(2000);
					RegisterRepo.sign_out(driver).click();
					 Thread.sleep(3000);
					 RegisterRepo.sign_in(driver).click();
					 Thread.sleep(3000);
					System.out.println("Valid user");
					 
				}
				
				else
				{
					System.out.println("Invalid user");
				}
			
			
			RegisterRepo.login(driver).clear();
		}


	}
	@AfterTest
	public void afterTest() 
	{
		driver.close();
	}

}


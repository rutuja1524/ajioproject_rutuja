package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PaymentRepo 
{
	static WebElement element;
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/");
	}
	
	public static void  Search_Bar(WebDriver driver)
	{
		driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[3]/div[2]/form/div/div/input")).sendKeys("Clocks For Home And Kitchen");
		

	}
	
	public static WebElement Searchbtn(WebDriver driver)
	{
		
		element=driver.findElement(By.className("rilrtl-button"));
		return element;
		
	}
	
	public static WebElement click_on_change_grid(WebDriver driver)
	{
		
		element = driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[2]/div[2]/div[2]/div/div[2]/div/div[2]/div"));
		return element;
		
	}
	

	public static WebElement click_on_pricebtn(WebDriver driver)
	{
	
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/ul/li[3]/div/div/div/span[2]"));
		return element;
		
	}
	
	public static WebElement click_on_price_range(WebDriver driver)
	{
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[2]/div[1]/div[2]/ul/li[3]/div/div/div[2]/ul/li[2]/div/div/label"));
		return element;
		
	}
	
	public static WebElement clickonproduct (WebDriver driver)
	{
		
		
				//*[contains(text(),'Floral Framed Analogue Wall Clock')]
		 element=driver.findElement(By.xpath("//*[contains(text(),'Floral Framed Analogue Wall Clock')]"));
		 return element;
	}
	
	
	
	/*public static WebElement clickonproduct_dtls (WebDriver driver)
	{
		//element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div/div[2]/div[4]/div/div/div/div[2]/div[3]/div/div[7]/div[2]/a/div"));
		
		 element=driver.findElement(By.xpath("//button[contains(text(),'Product Details')]"));
		 return element;
	}*/
	
	public static WebElement clickonAddtocart (WebDriver driver)
	{
		
		//element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div[3]/div/div[8]/div[1]/div[1]/div/span[2]"));
		element=driver.findElement(By.xpath("//*[contains(text(),'ADD TO BAG')]"));
		return element;
		
	}
	
	public static  WebElement clickonGo_To_bag (WebDriver driver)
	{										
		element=driver.findElement(By.xpath("//*[contains(text(),'GO TO BAG')]"));
		//element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/header/div[3]/div[2]/div[2]/a/div"));
		return element;	
		
		
	}
	
	
	public static WebElement clickonPlaceorder (WebDriver driver)
	{
		
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div[2]/div[2]/div[2]/div[2]/button"));
		return element;						
	}	

	
	public static void  login(WebDriver driver)
	{
		 driver.findElement(By.name("username")).sendKeys("8983197796");
		
	}

	 public static void Continue(WebDriver driver)
	 {
		 driver.findElement(By.cssSelector("input[value='Continue']")).click(); 
	 
	 }
	
	 public static WebElement startshopping(WebDriver driver) 
		{
			element=driver.findElement(By.cssSelector("input[value='START SHOPPING']"));
			//element=driver.findElement(By.className("login-form-inputs login-btn"));
			return element;
	 
		}
	
	 
	 public static WebElement clickonPlaceorder_confirm (WebDriver driver)
		{
		
			element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/div[2]/div[2]/div[2]"));
			return element;
		}
	 
	 public static WebElement card_no (WebDriver driver)
		{
		 
		
			element=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[1]/div/div[1]/div[2]/span[1]/input"));
			return element;
		}
	 
	 /*public static WebElement formFrame(WebDriver driver)
		{
			element= driver.findElement(By.xpath("/html/body/div[5]/div[2]/div/div/div[2]/div/div[1]/div[2]/div[2]/div/iframe"));
			return element;
		}*/

	 public static WebElement Name_on_card(WebDriver driver)
		{
		 
		
			element=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[2]/div/div/div[2]/input"));
			return element;
		}
	 
	 public static WebElement  clickonmonth(WebDriver driver)
		{
	        element=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[4]/div/div[1]/div/div/div/div"));
	        return element;
	    }
		public static WebElement  clickonyear(WebDriver driver)
		{
	        element=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[4]/div/div[2]/div/div/div/div/div"));
	        return element;
	    }
		public static WebElement  clickoncvv(WebDriver driver)
		{
	        element=driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[4]/div/div[3]/div/div/input"));
	        return element;
	    }
		
	   
		public static void  clickonpay(WebDriver driver)
		{
	        driver.findElement(By.xpath("/html/body/div[1]/div/div[2]/div[1]/div[3]/div[2]/div[2]/div/div/div/div[2]/form/div[6]/div/button")).click();
	    }
	}




package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Wish_List_Repo 
{
	static WebElement element;
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/");
	}
	
	public static  WebElement clickon_wishlist_btn (WebDriver driver)
	{										
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[1]/div/header/div[3]/div[2]/div[1]/img"));
		
		return element;	
		
		
	}
	
	
	

	
	public static void  login(WebDriver driver)
	{
		 driver.findElement(By.name("username")).sendKeys("8983197796");
		
	}

	 public static void Continue(WebDriver driver)
	 {
		 driver.findElement(By.cssSelector("input[value='Continue']")).click(); 
	 
	 }
	
	 public static WebElement startshopping(WebDriver driver) 
		{
			element=driver.findElement(By.cssSelector("input[value='START SHOPPING']"));
			//element=driver.findElement(By.className("login-form-inputs login-btn"));
			return element;
	 
		}
	
	 public static  WebElement clickon_wishlist (WebDriver driver)
		{										
			element=driver.findElement(By.xpath("//*[contains(@href,'/wishlist')]"));
			
			return element;	
			
			
		}
	 
	public static WebElement clickonproduct (WebDriver driver)
	{
		
		 element=driver.findElement(By.xpath("//*[contains(text(),'V-neck Cotton Top with Lace Insert')]"));
		 return element;
	}
	
public static WebElement clickonshare_btn(WebDriver driver)
	
	{										
		
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div[2]/div[1]/div[1]"));
		return element;
	}
	
public static WebElement clickonshare_pintrest(WebDriver driver)
	
	{										
		
		element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div[2]/div/div[2]/div[1]/div[2]/a[3]"));
		return element;
	}
	
public static void clickon_pintrest_Login(WebDriver driver)

{
	
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[3]/form/div[2]/fieldset/span/div/input")).sendKeys("rutuja1524@gmail.com");

}

public static void clickon_pintrest_pwd(WebDriver driver)

{
	
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[2]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[3]/form/div[4]/fieldset/span/div/input")).sendKeys("Rutuja@28");

}

public static void clickon_pintrest_Login_btn(WebDriver driver)

{
	
	driver.findElement(By.xpath("//*[@id=\"mweb-unauth-container\"]/div/div/div[2]/div/div/div/div/div/div/div/div/div/div[3]/div/div/div[3]/form/div[7]/button/div")).click();

}

public static WebElement My_save(WebDriver driver)

				{						
	
	element=driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div/div[1]/div/div/div/div/div[2]/div[1]"));
	return element;
}

public static WebElement My_save_btn(WebDriver driver)

{						

element=driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div/div[1]/div/div/div/div/div[2]/div[2]"));
return element;
}


public static WebElement Create(WebDriver driver)

{
	//*[@id="__PWS_ROOT__"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div
	element=driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div/div[2]/div/div/div"));
	return element;
}


/*public static WebElement Create(WebDriver driver)

{
	
	element=driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/div/div[2]/div/div/span"));
	return element;
}
*/
public static void Create_nm(WebDriver driver)

{
	
	driver.findElement(By.xpath("/html/body/div[1]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/form/div/div[2]/div[2]/span/div/input")).sendKeys("Top");
	
}

/*[@id="__PWS_ROOT__"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/form/div/div[5]/div[2]/div/button

html/body/div[1]/div[1]/div/div/div[2]/div/div/div/div*/

public static void Create_btn(WebDriver driver)

{	driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/form/div/div[5]/div[2]/div/button/div/div/div")).click();								
	//*[@id="__PWS_ROOT__"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/form/div/div[5]/div[2]/div/button/div/div/div
	
	//driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div/div[2]/div/div/form/div/div[5]/div[2]/div/button")).click();
	
}

public static void save_btn(WebDriver driver)

{								
	
	driver.findElement(By.xpath("//*[@id=\"__PWS_ROOT__\"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div[3]/div/div/a/div[1]/div/div")).click();
	
}

//*[@id="__PWS_ROOT__"]/div[1]/div/div/div[2]/div/div/div/div/div/div/div[3]/div/div/a/div[1]/div/div

}

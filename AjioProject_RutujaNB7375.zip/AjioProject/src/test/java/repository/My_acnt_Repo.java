package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class My_acnt_Repo
{

	static WebElement element;
	
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/login/register");
	}

	public static WebElement login(WebDriver driver)
	{
		element=driver.findElement(By.name("username"));
		return element;
	}

	 public static WebElement Continue(WebDriver driver)
	 {
		 element=driver.findElement(By.cssSelector("input[value='Continue']")); 
	 	return element;
	 }

	public static WebElement startshopping(WebDriver driver) 
	{
		element=driver.findElement(By.cssSelector("input[value='START SHOPPING']"));
		//element=driver.findElement(By.className("login-form-inputs login-btn"));
		return element;
		
	}
	public static WebElement my_acnt(WebDriver driver)
	{
		element=driver.findElement(By.linkText("My Account"));
		return element;
	}


	public static WebElement updt_personal_info(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"dAccountWrapper\"]/div[1]/div[3]/ul/a[1]/li"));
		return element;
	}
	
	public static WebElement confirm_otp_for_updtn(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"modalId\"]/div/div/div[2]/div[4]"));
		return element;
	}

	
	
	public static WebElement change_btn_pwd(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"updateProfileForm\"]/div[5]/span"));
		return element;
	}
	
	
	
	public static WebElement pwd_field(WebDriver driver)
	{
		element=driver.findElement(By.name("newEmail"));
		return element;
	}
	
	public static WebElement save_new_pwd_btn(WebDriver driver)
	{
		element=driver.findElement(By.cssSelector("input[value='SAVE NEW PASSWORD']"));
		return element;
	}
	
	
	public static WebElement sign_out(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Sign Out"));
		return element;
		
	}
	
	public static WebElement sign_in(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[1]/ul/li[1]/span"));
		return element;
		
	}
}

package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Customer_care_Repo 
{
static WebElement element;
	
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/");
	}

	
	public static WebElement C_C(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Customer Care"));
		return element;
	}
	
	
	/*public static WebElement search_bar (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"selfcare\"]/div[2]/div/form/div/div/input"));
		return element;
	}
	

	
	public static WebElement search_btn (WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"selfcare\"]/div[2]/div/form/div/button"));
		return element;
	}*/
	
}

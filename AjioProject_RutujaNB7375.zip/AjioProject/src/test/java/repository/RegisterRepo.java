package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegisterRepo 
{
	static WebElement element;
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/");
	}

	public static WebElement login(WebDriver driver)
	{
		element=driver.findElement(By.name("username"));
		return element;
	}

	 public static WebElement Continue(WebDriver driver)
	 {
	 	element=driver.findElement(By.className("login-btn"));
	 	return element;
	 }
	 
	 public static WebElement fGender(WebDriver driver)
	 {
	 	element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/form/div[3]/label[1]/span"));
	 	return element;
	 }
	 
	 public static WebElement mGender(WebDriver driver)
	 {
	 	element=driver.findElement(By.xpath("/html/body/div[1]/div/div/div/div/div[2]/form/div[3]/label[2]/span"));
	 	return element;
	 }
	 
	 
	
	 /*public static  WebElement welComeAdmin(WebDriver driver)
	 {
		 element=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[1]/ul/li[1]"));
	 	return element;
	 }*/
	 
	 public static  WebElement username(WebDriver driver)
	 {
		 element=driver.findElement(By.name("user-name"));
	 	return element;
	 }
	 
	 public static WebElement useremail(WebDriver driver)
	 {
		 element=driver.findElement(By.name("email-mob"));
	 	return element;
	 }
	 public static WebElement password(WebDriver driver)
	 {
		 element=driver.findElement(By.name("pwd"));
	 	return element;
	 }
	 
	 public static WebElement tickButton(WebDriver driver)
	 {
		 element=driver.findElement(By.className("checkbox"));
	 	return element;
	 }
	 
	 public static WebElement sendOTP(WebDriver driver)
	 {
		 element=driver.findElement(By.cssSelector("input[value='SEND OTP']"));
	 	return element;
	 }
	 
	 public static WebElement startshopping(WebDriver driver)
	 {
		 //element=driver.findElement(By.cssSelector("input[value='START SHOPPING']"));
		 element=driver.findElement(By.xpath("//*[@id=\"authWrapper\"]/div[2]/div/div/div[2]/form/div/div[3]/input"));
			return element;
			
		}
	 public static WebElement sign_out(WebDriver driver)
		{
			element=driver.findElement(By.linkText("Sign Out"));
			return element;
			
		}
		
	 /*public static WebElement back(WebDriver driver)
		{
			element=driver.findElement(By.xpath("//*[@id=\"authWrapper\"]/div/div/div/div/div[1]/span/span"));
			return element;
			
		}*/
		public static WebElement sign_in(WebDriver driver)
		{
			element=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[1]/ul/li[1]/span"));
			return element;
			
		}
}



package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SignInRepo 
{
	static WebElement element;
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/login/register");
	}

	public static WebElement login(WebDriver driver)
	{
		element=driver.findElement(By.name("username"));
		return element;
	}

	 public static WebElement Continue(WebDriver driver)
	 {
		 element=driver.findElement(By.cssSelector("input[value='Continue']")); 
	 	return element;
	 	
	 }
	 	public static WebElement sign_out(WebDriver driver)
	{
		element=driver.findElement(By.linkText("Sign Out"));
		return element;
		
	}
	 

	public static WebElement startshopping(WebDriver driver) 
	{
		element=driver.findElement(By.cssSelector("input[value='START SHOPPING']"));
		//element=driver.findElement(By.className("login-form-inputs login-btn"));
		return element;
		
	}
		
	
	
	public static WebElement sign_in(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[1]/ul/li[1]/span"));
		return element;
		
	}

}

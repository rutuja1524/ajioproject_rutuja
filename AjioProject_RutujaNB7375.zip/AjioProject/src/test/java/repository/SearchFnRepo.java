package repository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class SearchFnRepo 
{
	static WebElement element;
	
	public static void url (WebDriver driver)
	{
		driver.get("https://www.ajio.com/");
	}
	
	public static WebElement Search_Bar(WebDriver driver)
	{
		element=driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[3]/div[2]/form/div/div/input"));
		return element;
		
	}
	
	public static WebElement Searchbtn(WebDriver driver)
	{
		element=driver.findElement(By.className("rilrtl-button"));
		return element;
		
	}
}
	


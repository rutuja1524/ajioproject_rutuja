package Payment;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import repository.PaymentRepo;


public class PaymentTests
{

	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() throws InterruptedException
	 {

	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
	 }
	  @Test
	  public void f() throws InterruptedException, IOException 
	  {
		  FileInputStream file=new   FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
		  XSSFWorkbook w=new  XSSFWorkbook(file);
		  XSSFSheet s=w.getSheet("Payments");
		  //XSSFSheet s=w.getSheet("Sheet1");
		  
		  int rowsize=s.getLastRowNum();
		  
		  System.out.println("no of data:"+rowsize);
		
		  
		 PaymentRepo.url(driver);
		  Thread.sleep(2000);
		  
		  PaymentRepo.Search_Bar(driver);
		  Thread.sleep(2000);
			    
		  PaymentRepo.Searchbtn(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.click_on_change_grid(driver).click();
		  Thread.sleep(2000);
		  
		  PaymentRepo.click_on_pricebtn(driver).click();
		  Thread.sleep(2000);
		  
		  PaymentRepo.click_on_price_range(driver).click();
		  Thread.sleep(2000);
		  
		  Select s1=new Select(driver.findElement(By.xpath("//*[@id=\"products\"]/div[3]/div/div[3]/div/select")));
		  s1.selectByVisibleText("What's New");
		  Thread.sleep(3000);
		  
		  
		  
		  
		  JavascriptExecutor js=(JavascriptExecutor) driver;
		  js.executeScript("window.scrollBy(0,200)");
		  Thread.sleep(3000);
		  
		  
		  
		  Actions ac=new Actions(driver);
			
		  ac.moveToElement(PaymentRepo.clickonproduct(driver)).build().perform();
		  Thread.sleep(2000);
		  
		  PaymentRepo.clickonproduct(driver).click();
		  Thread.sleep(3000);
		  
		  //AddCart_Repo.clickonproduct_dtls(driver).click();
		  //Thread.sleep(3000);
		  
		  for(String wins : driver.getWindowHandles())
		  {
			  driver.switchTo().window(wins);
		  }
		  
		  
		  
		  PaymentRepo.clickonAddtocart(driver).click();
		  Thread.sleep(3000);
		  
		  System.out.println(driver.getTitle());
		  
		  PaymentRepo.clickonGo_To_bag(driver).click();
		  Thread.sleep(3000);
		 
		  PaymentRepo.clickonPlaceorder(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.login(driver);
		  Thread.sleep(3000);
		  
		  PaymentRepo.Continue(driver);
		  Thread.sleep(30000);
		  
		  PaymentRepo.startshopping(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.clickonPlaceorder_confirm(driver).click();
		  Thread.sleep(3000);
		  
		  
		  PaymentRepo.clickonPlaceorder_confirm(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.card_no(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.Name_on_card(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.clickonmonth(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.clickonyear(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.clickoncvv(driver).click();
		  Thread.sleep(3000);
		  
		  PaymentRepo.clickonpay(driver);
		  Thread.sleep(3000);
		  
		  
		//driver.switchTo().frame(PaymentRepo.formFrame(driver));
		  
		  
		  for(int i=1; i<=rowsize; i++)
		  {
			  String cardNo=s.getRow(i).getCell(0).getStringCellValue();
			  String name=s.getRow(i).getCell(1).getStringCellValue();
			  String month =s.getRow(i).getCell(2).getStringCellValue();
			  String year=s.getRow(i).getCell(3).getStringCellValue();
			  String cvv=s.getRow(i).getCell(4).getStringCellValue();
			 
			 
			  try
			  {
			  PaymentRepo.card_no(driver).sendKeys(cardNo);
			  Thread.sleep(4000);
			  PaymentRepo.Name_on_card(driver).sendKeys(name);
			  Thread.sleep(4000);
			  PaymentRepo.clickonmonth(driver).sendKeys(month);
			  Thread.sleep(4000);
			  PaymentRepo.clickonyear(driver).sendKeys(year);
			  Thread.sleep(4000);
			  PaymentRepo.clickoncvv(driver).sendKeys(cvv);
			  Thread.sleep(4000);
			  PaymentRepo.clickonpay(driver);
			  Thread.sleep(4000);
			  
			 /* if(driver.getTitle().equals("Payments"))
			  {
				  PaymentRepo.card_no(driver).clear();
				  
				  PaymentRepo.Name_on_card(driver).clear();
				  
				  PaymentRepo.clickonmonth(driver).clear();
				  
				  PaymentRepo.clickonyear(driver).clear();
				  
				  PaymentRepo.clickoncvv(driver).clear();
				  
			  }*/
			  
			  System.out.println("valid data");
			    System.out.println("");
			   
			    	 
			      }
		  
		 
		  catch(Exception e)
			      {
			    	 
			    	 System.out.println("invalid data");
			    	 System.out.println("");
			    	 
			      }
	  }
				  
}			
					
					
			  @AfterTest
				public void afterTest() 
				{
					driver.quit();
				}
			  
		  
		 
			 
		  }
		  
		  
		  
	 

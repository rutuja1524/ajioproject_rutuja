package AddCart;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

import repository.AddCart_Repo;

public class AddCart_Repo_Test
{
	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() throws InterruptedException
	 {

	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
	 }
	  @Test
	  public void f() throws InterruptedException, IOException 
	  {
		  FileInputStream file=new   FileInputStream("E:\\7375\\AjioProject\\Data\\AjioSheet.xlsx");
		  XSSFWorkbook w=new  XSSFWorkbook(file);
		  XSSFSheet s=w.getSheet("Add_cart");
		  
		  int rowsize=s.getLastRowNum();
		  
		  System.out.println("No of data:"+rowsize);
		  
		
		  AddCart_Repo.url(driver);
		  Thread.sleep(2000);
		  
		  AddCart_Repo.Search_Bar(driver);
		  Thread.sleep(2000);
			    
		  AddCart_Repo.Searchbtn(driver).click();
		  Thread.sleep(3000);
		  
		  AddCart_Repo.click_on_change_grid(driver).click();
		  Thread.sleep(2000);
		  
		  AddCart_Repo.click_on_pricebtn(driver).click();
		  Thread.sleep(2000);
		  
		  AddCart_Repo.click_on_price_range(driver).click();
		  Thread.sleep(2000);
		  
		  Select s1=new Select(driver.findElement(By.xpath("//*[@id=\"products\"]/div[3]/div/div[3]/div/select")));
		  s1.selectByVisibleText("What's New");
		  Thread.sleep(3000);
		  
		  
		  
		  
		  JavascriptExecutor js=(JavascriptExecutor) driver;
		  js.executeScript("window.scrollBy(0,200)");
		  Thread.sleep(3000);
		  
		  
		  
		  Actions ac=new Actions(driver);
			
		  ac.moveToElement(AddCart_Repo.clickonproduct(driver)).build().perform();
		  Thread.sleep(2000);
		  
		  AddCart_Repo.clickonproduct(driver).click();
		  Thread.sleep(3000);
		  
		  //AddCart_Repo.clickonproduct_dtls(driver).click();
		  //Thread.sleep(3000);
		  
		  for(String wins : driver.getWindowHandles())
		  {
			  driver.switchTo().window(wins);
		  }
		  
		  
		  
		  AddCart_Repo.clickonAddtocart(driver).click();
		  Thread.sleep(3000);
		  
		  System.out.println(driver.getTitle());
		  
		  AddCart_Repo.clickonGo_To_bag(driver).click();
		  Thread.sleep(3000);
		 
		  AddCart_Repo.clickonPlaceorder(driver).click();
		  Thread.sleep(3000);
		  
		  AddCart_Repo.login(driver);
		  Thread.sleep(3000);
		  
		  AddCart_Repo.Continue(driver);
		  Thread.sleep(20000);
		  
		  AddCart_Repo.startshopping(driver).click();
		  Thread.sleep(3000);
		  
		  AddCart_Repo.clickonPlaceorder_confirm(driver).click();
		  Thread.sleep(3000);
		  
		  AddCart_Repo.clickonChange_btn(driver).click();
		  Thread.sleep(3000);
		 
		  
		  
		  for(int i=1; i<=rowsize; i++)
		  {
			  String pincode=s.getRow(i).getCell(0).getStringCellValue();
			  String Area=s.getRow(i).getCell(1).getStringCellValue();
			  String Building=s.getRow(i).getCell(2).getStringCellValue();
			  String landmark=s.getRow(i).getCell(3).getStringCellValue();
			  String city=s.getRow(i).getCell(4).getStringCellValue();
			  String state=s.getRow(i).getCell(5).getStringCellValue();
			
				  
			  System.out.println(pincode + " , "+Area+" , "+Building + " , "+landmark + " , "+city+ " , "+state);
		  
			
				 try 
				 {
		  
		  AddCart_Repo.clickonnewaddress(driver).click();
		  Thread.sleep(4000);
		  
		  AddCart_Repo.pincode(driver).sendKeys(pincode);
		  Thread.sleep(6000);
		  
		  AddCart_Repo.area(driver).sendKeys(Area);
		  Thread.sleep(4000);
		  
		  AddCart_Repo.building_nm(driver).sendKeys(Building);
		  Thread.sleep(6000);
		  
		  AddCart_Repo.landmark(driver).sendKeys(landmark);
		  Thread.sleep(6000);
		  
		  AddCart_Repo.city(driver).sendKeys(city);
		  Thread.sleep(6000);
		  
		  AddCart_Repo.state(driver).sendKeys(state);
		  Thread.sleep(6000);
		 
		  AddCart_Repo.ClickonSave(driver).click();
		  Thread.sleep(8000);
		  
		
		  /*if(driver.getTitle().equals("Shipping"))
		  {
			  driver.navigate().back();
			  
			  System.out.println("valid data");
		      System.out.println("");
		  }
		  else 
		  {
			  System.out.println("invalid data");
		      System.out.println("");
			  //driver.findElement(By.id("fdclose")).click();
		  }*/
			  
		
		 /* if(driver.getTitle().equals("Shipping"))
		  {
			  AddCart_Repo.pincode(driver).clear();
			  Thread.sleep(6000);
			  
			  AddCart_Repo.area(driver).clear();
			  Thread.sleep(4000);
			  
			  AddCart_Repo.building_nm(driver).clear();
			  Thread.sleep(6000);
			  
			  AddCart_Repo.landmark(driver).clear();
			  Thread.sleep(6000);
			  
			  AddCart_Repo.city(driver).clear();
			  Thread.sleep(6000);
			  
			  AddCart_Repo.state(driver).clear();
			  Thread.sleep(6000);*/
		  
		  
		  	 System.out.println("valid data");
				    System.out.println("");
				   
				    	 
				      }
			 
			  catch(Exception e)
				      {
				    	 
				    	 System.out.println("invalid data");
				    	 System.out.println("");
				    	 
				      }
		  }
					  
	  }			
						
						
				  @AfterTest
					public void afterTest() 
					{
						driver.quit();
					}
				  
			  }
			 
			  	



package AddCart;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ajio_add_cart_test
{

public static void main(String[] args) throws InterruptedException
{
WebDriver driver;
{
	 WebDriverManager.chromedriver().setup();
	 driver=new ChromeDriver();
	 driver.manage().window().maximize();
	 
	 
	 driver.get("https://www.ajio.com/");
	 Thread.sleep(2000);
	 driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[1]/div/header/div[3]/div[2]/form/div/div/input")).sendKeys("footware");
	 driver.findElement(By.className("rilrtl-button")).click();
	 
	 //item
	 driver.findElement(By.xpath("//*[@id=\"products\"]/div[3]/div[1]/div/div[1]/a/div/div[1]/img")).click();
	 
	 String parentWin=driver.getWindowHandle();
	 
	  for(String wins : driver.getWindowHandles())
	  {
		  driver.switchTo().window(wins);
	  }
	  Thread.sleep(2000);
	  
	  //size
	 driver.findElement(By.xpath("//*[@id=\"appContainer\"]/div[2]/div/div/div[2]/div/div[3]/div/div[6]/div[2]/div/div/div[2]/div/span")).click();
	 Thread.sleep(2000);
	 //addcart
	  driver.findElement(By.xpath("/html/body/div[1]/div/div/div[2]/div/div/div[2]/div/div[3]/div/div[9]/div[1]/div[1]/div/span[2]")).click();
}
}
}
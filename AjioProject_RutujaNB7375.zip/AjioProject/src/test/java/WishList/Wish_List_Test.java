package WishList;

import java.io.IOException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;
import repository.Wish_List_Repo;


public class Wish_List_Test
{

	WebDriver driver;
	 @BeforeTest
	  public void beforeTest() throws InterruptedException
	 {

	     WebDriverManager.chromedriver().setup();
		 driver=new ChromeDriver();
		 driver.manage().window().maximize();
		 Thread.sleep(2000);
	 }
	 
	 @Test
	 public void f() throws InterruptedException
	  {
	 
	 Wish_List_Repo.url(driver);
	 Thread.sleep(2000);
	 
	 Wish_List_Repo.clickon_wishlist_btn(driver).click();
	 Thread.sleep(2000);
	 
	 Wish_List_Repo.login(driver);
	 Thread.sleep(2000);
	 
	 Wish_List_Repo.Continue(driver);
	 Thread.sleep(30000);
	 
	 Wish_List_Repo.startshopping(driver).click();;
	 Thread.sleep(2000);
	 
	 
	 Wish_List_Repo.clickon_wishlist(driver).click();
	 Thread.sleep(2000);
	 
	 JavascriptExecutor js=(JavascriptExecutor) driver;
	  js.executeScript("window.scrollBy(0,2000)");
	  Thread.sleep(3000);
	  
	 
	 Actions ac=new Actions(driver);
		
	  ac.moveToElement( Wish_List_Repo.clickonproduct(driver)).build().perform();
	  Thread.sleep(3000);
	  
	  Wish_List_Repo.clickonproduct(driver).click();
	  Thread.sleep(3000);
	 
	  System.out.println(driver.getTitle());
	  
	 for(String wins : driver.getWindowHandles())
	  {
		  driver.switchTo().window(wins);
	  }
	 
	 
	 Actions ac1=new Actions(driver);
		
	  ac.moveToElement( Wish_List_Repo.clickonshare_btn(driver)).build().perform();
	  Thread.sleep(2000);
	  
	  Wish_List_Repo.clickonshare_pintrest(driver).click();
		 Thread.sleep(2000);
		 
	 
	
	 
	 for(String wins1 : driver.getWindowHandles())
	  {
		  driver.switchTo().window(wins1);
	  }
	 
	 
	 Wish_List_Repo.clickon_pintrest_Login(driver);
	 Thread.sleep(2000);
	 
	 Wish_List_Repo.clickon_pintrest_pwd(driver);
	 Thread.sleep(2000);
	 
	 Wish_List_Repo.clickon_pintrest_Login_btn(driver);
	 Thread.sleep(2000);
	 
	 System.out.println(driver.getTitle());
	 
	/* Actions ac2=new Actions(driver);
		
	  ac.moveToElement( Wish_List_Repo.My_save(driver)).build().perform();
	  Thread.sleep(2000);
	  
	 Wish_List_Repo.My_save_btn(driver).click();
	 
	 
	 Wish_List_Repo.Create(driver).click();
	 Thread.sleep(6000);
	 Wish_List_Repo.Create_nm(driver);
	 Thread.sleep(4000);
	 Wish_List_Repo.Create_btn(driver);
	 Thread.sleep(4000);
	 Wish_List_Repo.save_btn(driver);
	 Thread.sleep(2000);*/

	 
	 System.out.println("Successfully save on pintrest");
	  }
	 
	 @AfterTest
		public void afterTest() 
		{
			driver.quit();
		}
	  
}
	 

